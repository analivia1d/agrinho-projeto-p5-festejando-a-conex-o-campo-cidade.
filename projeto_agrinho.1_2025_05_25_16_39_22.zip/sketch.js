function setup() {
  createCanvas(400, 400);
}

let xJogador = [0, 0, 0, 0];
let yJogador = [100, 200, 300];

function draw() {
  ativaJogo();
  desenhaJogadores();
  desenhaLinhaDeChegada();
  verificaVencedor();
  instruções();
}

function instruções(){
if(focused==false){
textSize(14)
text("clique com o botão direito no mouse para começar o jogo.", 25 ,20)
text("A conexão entre o campo e a cidade é essencial para o funcionamento de ambos. Embora pareçam mundos diferentes, eles dependem um do outro: o campo fornece alimentos e a cidade contribui com tecnologias e inovações. Essa relação deve ser valorizada, pois é por meio dela que conseguimos avanços importantes, como o uso de máquinas no campo e maior consciência ecológica nas cidades.Qual é a principal razão apresentada no texto para celebrar a conexão entre o campo e a cidade?A) Porque o campo e a cidade possuem culturas distintas que precisam ser preservadas separadamente.B) Porque a sobrevivência da sociedade depende da colaboração entre o campo, que produz alimentos, e a cidade, que desenvolve tecnologias e promove o consumo.Clique A para A e  S para B.", 10 ,30,300)
}

}

function ativaJogo() {
  if (focused == true) {
    background("#B5B9EB");
  } else {
    background("rgb(214,178,238)");
  }
}

function desenhaJogadores() {
  textSize(30);
  text("🌱", xJogador[0], yJogador[0]);
  text("🥬", xJogador[1], yJogador[1]);
}

function desenhaLinhaDeChegada() {
  fill("white");
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  if (xJogador[0] > 350) {
    text("Você errou!", 50, 200);
    noLoop();
  }
  if (xJogador[1] > 350) {
    text("Você acertou!", 50, 200);
    noLoop();
  }
  if (xJogador[2] > 350) {
    text("Jogador 3 venceu!", 50, 200);
    noLoop();
  }
}

function keyReleased() {
  if (key == "a") {
    xJogador[0] += random(20);
  }
  if (key == "s") {
    xJogador[1] += random(20);
  }
  if (key == "d") {
    xJogador[2] += random(20);
  }
}
